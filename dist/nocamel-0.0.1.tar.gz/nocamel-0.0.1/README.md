# nocamel
Convert a python file from camel case to PEP compliant style. <br>
Install with:<br>
<pre>
pip install nocamel
</pre>




<br>
Usage:
<pre>

</pre>